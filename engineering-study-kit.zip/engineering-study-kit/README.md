# Engineering Study Kit V0

A portable, read-only-first codebase study kernel for humans and AI agents. It records subsystem maps, execution flows, source-anchored evidence and potential findings as Markdown and JSONL inside a `.study/` directory, with a disposable SQLite index for search. Python 3.9+, standard library only. Study mode only: V0 never edits the target source.

## Contents

```text
README.md  AGENTS.md  PROTOCOL.md  schema.json  kernel.py
templates/{system,flow,finding,run}.md
tests/test_kernel.py      examples/minimal/
```

## Install into a repository

```bash
python /path/to/kit/kernel.py init --root /path/to/target-repo
cp /path/to/kit/AGENTS.md /path/to/target-repo/AGENTS.md    # or merge into your existing one
cd /path/to/target-repo
python .study/kernel.py status
python .study/kernel.py orient
```

`init` needs `kernel.py`, `PROTOCOL.md`, `schema.json` and `templates/` next to it, and copies them into `.study/`. It refuses to overwrite existing kit files without `--force`, never touches durable records, and appends four ignore patterns for the disposable files to `.git/info/exclude`. That append is its only write outside `.study/`. The kit has no dependencies; vendoring `.study/` into the repository is enough for others.

## Quick start

```bash
python .study/kernel.py run start --goal "Map the login flow"              # RUN-0001
python .study/kernel.py new system auth --title "Authentication" --area src/auth --run RUN-0001
python .study/kernel.py anchor add SYS-auth src/auth/token.py --symbol verify_token --run RUN-0001
python .study/kernel.py evidence add ANC-0001 --type source-inspection --result "..." --run RUN-0001
python .study/kernel.py claim add SYS-auth "verify_token rejects empty tokens" --anchor ANC-0001 --evidence EV-0001 --run RUN-0001
python .study/kernel.py finding "Expiry not checked" --severity medium --anchor ANC-0001 --run RUN-0001
python .study/kernel.py set F-0001 --status triaged --run RUN-0001
python .study/kernel.py check
python .study/kernel.py search token expiry
python .study/kernel.py run end --id RUN-0001 --summary "Mapped auth entry points" --next "Trace refresh"
```

A complete runnable walkthrough is in `examples/minimal/README.md`. Every command accepts `-h` with an example.

## Commands

| Command | Purpose |
|---|---|
| `init [--force]` | Install `.study/`, build the index |
| `orient` | Read-only survey: languages, build tools, tests, entry-point candidates (works before `init`) |
| `run start --goal` / `run end --id --summary` | Open a run with a source snapshot; close it, verify source unchanged, write the handoff |
| `new system\|flow SLUG --title --run` | Create a document from a template |
| `finding TITLE --severity --run` | Record a potential issue (never a fix) |
| `claim add DOC "text" --anchor/--evidence` | Append a numbered, grounded claim to a system or flow |
| `set ID --status/--confidence [--note]` | Change status or confidence; logged in the document's Status log |
| `anchor add DOC PATH` | Bind a document to source lines with a fingerprint and the Git SHA |
| `evidence add SUBJECT --type --result` | Append an evidence record to the run |
| `show`, `list`, `search`, `graph` | Read records, links, backlinks and evidence |
| `coverage` | Anchored vs unanchored files (descriptive only) |
| `check` | Validate records, anchors and index rebuildability |
| `rebuild` | Rebuild `study.db` from the durable records |
| `status` | Counts, open runs, anchor states, items needing attention |

Global options: `--root`, `--study-dir`, `--agent` (or `STUDY_AGENT`), `--json`, `--max-event-bytes`. `STUDY_DISABLE_FTS=1` forces the non-FTS search path. Errors print `error: ...` to stderr and exit 1.

## How it stays honest

- Markdown and JSONL are the source of truth. `study.db` can be deleted and rebuilt at any time.
- Anchors prove provenance, not correctness. `ok` means the file, symbol text and fingerprint still match. It does not mean the claim is true.
- Stale and missing anchors are warnings (exit 0). Malformed records, duplicate IDs, unknown links and invalid evidence are errors (exit 1).
- `verified` confidence is reserved and rejected in V0.
- `run end` compares Git HEAD and working-tree state with the run's start snapshot and marks the run `source_changed` if they differ.

## Known limitations

- Safety. The guardrails constrain `kernel.py`, not an agent that also has a shell. A prompt such as `AGENTS.md` is a request, not enforcement. For real isolation, mount the source read-only, keep `.study/` in a separate writable location, disable the network, and omit credentials (see Future hardening in `PROTOCOL.md`).
- Symbol lookup is a text heuristic, not a parser. Without a line range, a symbol anchor covers only its first matching line.
- Without Git there is no source-change guard, and freshness relies on fingerprints alone.
- Concurrent writers are not coordinated beyond exclusive file creation; use one active run per writer.
- `orient` is filename and layout heuristics only. Entry points it lists are candidates, not findings.
- No Change or Verify modes.

## Tests

```bash
python -m unittest discover -s tests -v
```

The suite builds temporary repositories, uses `unittest` only, and skips Git-specific tests if `git` is missing.
